/*
Sayem Chowdhury 
Lab #3 [part: 1]
*/
#include "ListArray.h"

template < typename DataType > // Defination of default constructor 
List<DataType>::List ( int maxNumber ) 
{
	maxSize = maxNumber;
	size = 0;
	cursor = -1;
	dataItems = new DataType[maxSize];

}

template < typename DataType >
List<DataType>::List ( const List& source ) //Defination of copy constructor
{
	maxSize = source.maxSize;
	size = source.size;
	cursor = 0;
	dataItems = new DataType[maxSize];
	for (; cursor <size; cursor++)
	{
		dataItems[cursor] = source.dataItems[cursor];
	}

}
    
template < typename DataType >
List<DataType>& List<DataType>::operator= ( const List& source ) //Defination of over loading Assignment operator 
{
	if (this != &source)
	{
		size = source.size;
		cursor = source.cursor;
		maxSize = source.maxSize;
		dataItems = new DataType[maxSize];
		for (int i = 0; i < size; i++)
		{
			dataItems[i] = source.dataItems[i];
		}

	}

	return *this;
}

template < typename DataType > //Defination of destructor
List<DataType>::~List ()
{
	delete [] dataItems;
}

template < typename DataType >
void List<DataType>::insert ( const DataType& newDataItem ) 
	throw ( logic_error )
{
	if (isFull())
		throw logic_error("The Array is Full");
	if (isEmpty())
	{
		size = 1;
		cursor = 0;
		dataItems[cursor] = newDataItem;
		//cursor++; 
	}
	else
	{
		for (int i = size - 1; i > cursor + 1; i--)
		{
			dataItems[i + 1] = dataItems[i]; // shift right
		}
			size++;
			dataItems[++cursor] = newDataItem;
			
		
	}
}

template < typename DataType >
void List<DataType>::remove () throw ( logic_error )
{
	//shift array to the left
	if (isEmpty())
	{
		throw ("The List is empty");
	}
	else
	for (int i = cursor; i < size - 1; i++)
	{
		dataItems[i] = dataItems[i + 1];
	}
	size--;
	cursor--;

}

template < typename DataType >
void List<DataType>::replace ( const DataType& newDataItem )
	throw ( logic_error )
{
	if (isEmpty())
		throw (" The List is empty");
	else
	{
		dataItems[cursor] = newDataItem;
	}	
}

template < typename DataType >
void List<DataType>::clear ()
{
	delete[] dataItems;
	size = 0;
	cursor = -1;
	dataItems = new DataType[maxSize];
}

template < typename DataType >
bool List<DataType>::isEmpty () const
{
	return (size == 0);
	//return false;
}

template < typename DataType >
bool List<DataType>::isFull () const
{
	return (size == maxSize);
	//return false;
}

//End of Part (1)







//*********************************************************************//
//																	   //
//                                 Part 2                              //
//																	   //	
//*********************************************************************//
template < typename DataType >
void List<DataType>::gotoBeginning ()
        throw ( logic_error )
{
	if (isEmpty())
		throw (" The List is empty");
	else
	{
		cursor = 0;
	}
}

template < typename DataType >
void List<DataType>::gotoEnd ()
        throw ( logic_error )
{
	if (isEmpty())
		throw (" The List is empty");

	else if(cursor!=maxSize-1)
	{
		cursor = size-1;
	}
}

template < typename DataType >
bool List<DataType>::gotoNext ()
        throw ( logic_error )
{
	if (isFull())
		throw (" The List is empty");
	else if(cursor!=size-1)

	{
		 cursor++;
	}
	
	//return false;
}

template < typename DataType >
bool List<DataType>::gotoPrior ()
        throw ( logic_error )
{
	if (isEmpty())
		throw ("The List is empty");
	else
	{
		cursor--;
	}
	//return false;
}

template < typename DataType >
DataType List<DataType>::getCursor () const
        throw ( logic_error )
{
	if (isEmpty())
	{
		throw("The list is emty");
	}

	else
	{
		DataType t;
		t = dataItems[cursor];
		return t;
	}
}


template < typename DataType >
void List<DataType>::moveToNth ( int n )
        throw ( logic_error )
{
	DataType temp;
	temp = dataItems[n];
	dataItems[n] = dataItems[cursor];
	dataItems[cursor] = temp;
}

template < typename DataType >
bool List<DataType>::find ( const DataType& searchDataItem )
        throw ( logic_error )
{
	if (isEmpty())
		throw (" The List is empty");
	else if

	{
		for (int i = 0; i < size - 1; i++)
		{
			if (dataitems[i] == searchDataItem)
				return true;
			else
				return   false;
		}
	}
	return false;
}

template <typename DataType>
void List<DataType>::showStructure() const

// outputs the data items in a list. if the list is empty, outputs
// "empty list". this operation is intended for testing/debugging
// purposes only.

{
	int j;   // loop counter

	if (size == 0)
		cout << "empty list" << endl;
	// The Ordered List code blows up below. Since this is just debugging
	// code, we check for whether the OrderedList is defined, and if so,
	// print out the key value. If not, we try printing out the entire item.
	// Note: This assumes that you have used the double-inclusion protection
	// in your OrderedList.cpp file by doing a "#ifndef ORDEREDLIST_CPP", etc.
	// If not, you will need to comment out the code in the section under 
	// the "else", otherwise the compiler will go crazy in lab 4.
	// The alternative is to overload operator<< for all data types used in
	// the ordered list.
	else
	{
		cout << "size = " << size
			<< "   cursor = " << cursor << endl;
		for (j = 0; j < maxSize; j++)
			cout << j << "\t";
		cout << endl;
		for (j = 0; j < size; j++) {
			if (j == cursor) {
				cout << "[";
				cout << dataItems[j]
#ifdef ORDEREDLIST_CPP
					.getKey()
#endif
					;
				cout << "]";
				cout << "\t";
			}
			else
				cout << dataItems[j]
#ifdef ORDEREDLIST_CPP
				.getKey()
#endif
				<< "\t";
		}
		cout << endl;
	}
}