
//Sayem Chowdhury 
//CSC <2210> Lab#9 Part:1
//--------------------------------------------
//======================================================
#include "BSTree.h"

template <typename DataType, class KeyType>
BSTree<DataType, KeyType>::BSTreeNode::BSTreeNode ( const DataType &nodeDataItem, BSTreeNode *leftPtr, BSTreeNode *rightPtr )
{
	//constructor of the class BSTreeNode 
	dataItem = nodeDataItem;
	left = leftPtr;
	right = rightPtr;
}
//---------------------------------------------------[BSTree ()]---------------------------------------------------------
template < typename DataType, class KeyType >
BSTree<DataType, KeyType>::BSTree () //implementation of default constructor
{
	root = NULL;
}

//-------------------------------------------------[BSTree (other)]--------------------------
template < typename DataType, class KeyType >
BSTree<DataType, KeyType>::BSTree ( const BSTree<DataType,KeyType>& other ) //Implementation of copy constructor
{
	*this = other; //using overloaded assignment operator
} 
//-------------------------------------------[isEmpty()]-------------------------------------------------------------------
template<typename DataType, class KeyType>
bool BSTree<DataType, KeyType>::isEmpty() const
{
	return root == NULL;
}

//--------------------------------------------[operator=]-------------------------------------------------------------------
template < typename DataType, class KeyType >
BSTree<DataType, KeyType>& BSTree<DataType, KeyType>:: operator= ( const BSTree<DataType,KeyType>& other )
{
	if (this != &other)
	{
		clear();
		copyTree( other);
		return *this;

	}
	return *this;
} 
//--------------------------------[copyTree-]--------------------------------------------------
template<typename DataType, class KeyType>
void BSTree<DataType, KeyType>::copyTree(const BSTree<DataType, KeyType>& otherTree)
{ 
	copyTreeHelper(root, otherTree.root);
} 

//-----------------------------------[copyTreeHelper]--------------------------------------------
template<typename DataType, class KeyType>
void BSTree<DataType, KeyType>::copyTreeHelper(BSTreeNode *& p, const BSTreeNode *otherPtr)
{
	if (otherPtr!=NULL)
	{
		p = new BSTreeNode(otherPtr->dataItem, NULL, NULL);
		copyTreeHelper(p->left, otherPtr->left);
		copyTreeHelper(p->right, otherPtr->right);
	}

	/*
	//Alternative approach
	if (otherPtr==NULL)
	{
		p = NULL;
	} 
	else
	{
		p = new BSTreeNode(otherPtr->dataItem, NULL, NULL);

		if (otherPtr->left != NULL)
		{
			copyTreeHelper(p->left, otherPtr->left);
		}

		if (otherPtr->right != NULL)
		{	
			copyTreeHelper(p->right, otherPtr->right);
		}
	}
	*/
}


//--------------------------[~BSTree()]-----------------------------------
//Destructor//delete all the nodes of the tree
template < typename DataType, class KeyType >
BSTree<DataType, KeyType>::~BSTree ()
{
	clear();
}

//Insert
//-------------------------------[insert]---------------------------------------
template < typename DataType, class KeyType >
void BSTree<DataType, KeyType>::insert ( const DataType& newDataItem )
{ 
	insertHelper(root, newDataItem);
}

//Insert Helper
//-------------------------------------[insertHelper]---------------------------------------
template < typename DataType, class KeyType >
void BSTree<DataType, KeyType>::insertHelper(BSTreeNode *&p, const DataType &newDataItem)
{
	if (p == NULL)
	{
		//insert new node 
		p = new BSTreeNode(newDataItem, 0, 0);

	}
	else if (newDataItem.getKey()>p->dataItem.getKey())
	{
		insertHelper(p->right, newDataItem);
	}
	else if (newDataItem.getKey()<p->dataItem.getKey())
	{
		insertHelper(p->left, newDataItem);
	}
	else
	{
		p->dataItem = newDataItem;
	}
}

//----------------------------------------[retrieve]-------------------------------------------------------
template < typename DataType, class KeyType >
bool BSTree<DataType, KeyType>::retrieve ( const KeyType& searchKey, DataType& searchDataItem ) const
{
	//return false;
	return retrieveHelper(root, searchKey, searchDataItem);

}
//---------------------------------------[retrieveHelper]------------------------------------------------------------------
template<typename DataType, class KeyType>
bool BSTree<DataType, KeyType>::retrieveHelper(BSTreeNode * p, const KeyType & searchKey, DataType & searchDataItem) const
{
	//
	if (p != NULL) //while tree is not empty
	{
		if (p->dataItem.getKey() == searchKey)
		{
			searchDataItem= p->dataItem;
			return true;
		}

		else if (p->dataItem.getKey() > searchKey)
		{
			return retrieveHelper(p->left, searchKey, searchDataItem);
		}

		else
		{
			return retrieveHelper(p->right, searchKey, searchDataItem);
		}
	}
	
	else
	{
		return false;
		// and that means searchDataItem remain undefined 
	}
	//return false;
}

///-------------------------------[remove]--------------------------------------------------------

template < typename DataType, class KeyType >
bool BSTree<DataType, KeyType>::remove ( const KeyType& deleteKey )
{
	//need to do
	return false;

}
//----------------------------------[removeHelper]--------------------------------------------------------------

template<typename DataType, class KeyType>
bool BSTree<DataType, KeyType>::removeHelper(BSTreeNode *& p, const KeyType & deleteKey)
{
	//need to do 
	return false;
}
//-------------------------------------[cutRightmost]-----------------------------------------------------------------

template<typename DataType, class KeyType>
void BSTree<DataType, KeyType>::cutRightmost(BSTreeNode *& r, BSTreeNode *& delPtr)
{
}

//--------------------------------[writeKeys]---------------------------------------

template < typename DataType, class KeyType >
void BSTree<DataType, KeyType>::writeKeys () const
{
	writeKeysHelper(root);
} 

//-------------------------------[writeKeysHelper]----------------------------------
template<typename DataType, class KeyType>
void BSTree<DataType, KeyType>::writeKeysHelper(BSTreeNode * p) const
{
	if (p == NULL)
	{
		return;
	}
	writeKeysHelper(p->left);
	cout << p->dataItem.getKey() << "->";
	writeKeysHelper(p->right);
}

//--------------------------[clear]---------------------------------------
template < typename DataType, class KeyType >
void BSTree<DataType, KeyType>::clear ()
{
	clearHelper(root);
	root = NULL;
}

//--------------------------[clearHelper]------------------------------------------------
template<typename DataType, class KeyType>
void BSTree<DataType, KeyType>::clearHelper(BSTreeNode * p)
{
	{
		if (p != NULL)
		{
			clearHelper(p->left);
			clearHelper(p->right);
			delete p;	
		}
		p = NULL;
	}
}


//-----------------------------------[getHeight]----------------------------------------

template < typename DataType, class KeyType >
int BSTree<DataType, KeyType>::getHeight () const
{
	return getHeightHelper(root);
}

//------------------------------[getHeightHelper]-----------------------------------------------

template<typename DataType, class KeyType>
int BSTree<DataType, KeyType>::getHeightHelper(BSTreeNode * p) const
{
	if ((p == NULL) || (p->left == NULL && p->right == NULL)) 
	{
		return 0; // only root and root with no children has a height of 0.
	} 
	else
	{
		int left_height;
		int right_height;

		left_height=  getHeightHelper(p->left) + 1;
		right_height= getHeightHelper(p->right) + 1; 

		int HEIGHT=(left_height >= right_height) ?  left_height :  right_height;
		return HEIGHT;	

			/*
			if (left_height >= right_height)
			{
				return left_height;
			}
			else
			{
				return right_height;
			}
			*/
	}

	//return 0;
}

//----------------[getcount]-------------------

template < typename DataType, class KeyType >
int BSTree<DataType, KeyType>::getCount () const
{
	//
	return getCountHelper(root);
	//return -1;
}

//----------------[getCountHelper]-----------------------------------

template<typename DataType, class KeyType>
int BSTree<DataType, KeyType>::getCountHelper(BSTreeNode * p) const

{
	if (p == NULL) //when tree is empty
		return(0);

	else if (p->left == NULL && p->right == NULL) // when only root no child
		return(1);

	else
		return(1 + (getCountHelper(p->left) + getCountHelper(p->right)));//when root has children
}


//------------------------------[writeLessThan]---------------------------------------------

template < typename DataType, class KeyType >
void BSTree<DataType, KeyType>::writeLessThan ( const KeyType& searchKey ) const
{
	//need to do  in next lab
}

//--------------------------------[writeLTHelper]------------------------------------------------------------
template<typename DataType, class KeyType>
void BSTree<DataType, KeyType>::writeLTHelper(BSTreeNode * p, const KeyType & searchKey) const
{
	//need to do in next lab
}


#include "show9.cpp"


