/**
 * Text class (Lab 1) configuration file.
 * Activate test 'N' by defining the corresponding LAB1_TESTN to have the value 1.
 */

#define LAB1_TEST1	0		// Programming exercise 2: toUpper and toLower
#define LAB1_TEST2	0		// Programming exercise 3: ==, <, and >
#define LAB2_TEST1  	1		// Programming recursion
#define LAB2_TEST2  	1		// Programming operation + and recursion
