//Sayem Chowdhury 
//fr9838
//lab #11
//================================================================

#include "Heap.h"

template < typename DataType, typename KeyType, typename Comparator >
Heap<DataType,KeyType,Comparator>::Heap ( int maxNumber = DEFAULT_MAX_HEAP_SIZE )
{
	size = 0;
	maxSize = maxNumber;
	dataItems = new DataType[maxSize];
}

template < typename DataType, typename KeyType, typename Comparator >
Heap<DataType,KeyType,Comparator>::Heap ( const Heap& other )
{
	*this = other;	
}

template < typename DataType, typename KeyType, typename Comparator >
Heap<DataType,KeyType,Comparator>& Heap<DataType,KeyType,Comparator>::operator= ( const Heap& other )
{
	if (this == &other)
		return *this;
	if (!isEmpty())
		clear();
	size = other.size;
	maxSize = other.maxSize;

	for (int i = 0; i < size; i++)
		dataItems[i] = other.dataItems[i];

	return *this;
}


template < typename DataType, typename KeyType, typename Comparator >
Heap<DataType,KeyType,Comparator>::~Heap ()
{
	clear();
	delete [] dataItems;
}

template < typename DataType, typename KeyType, typename Comparator >
void Heap<DataType,KeyType,Comparator>::insert ( const DataType &newDataItem )
    throw ( logic_error )
{
	if (isFull())
	{
		throw logic_error ("Heap is Full");
	}

	else
	{
		int n = size;    // starting index=size=0
		Comparator com;
		dataItems[size] = newDataItem;

		//[ bool operator()(const KeyType &a, const KeyType &b) const { return a < b; }]  

		while (com(dataItems[n].getPriority(), dataItems[(n - 1) / 2].getPriority())) // while violation in heap priority
		{ 
			//Swap the index data item to the parent data item
			DataType data = dataItems[n];             //save inserting item to data
			dataItems[n] = dataItems[(n - 1) / 2];    // calculation parent = (n-1)/2 
			dataItems[(n - 1) / 2] = data;
			n = (n- 1) / 2; // update index
		}
		size++; // 
	}
}

template < typename DataType, typename KeyType, typename Comparator >
DataType Heap< DataType,KeyType,Comparator >::remove () throw ( logic_error )
{
	if (isEmpty())
	{
		throw logic_error("Heap is Empty, Can't Remove from empty heap");
	}

	size--;  //decrement the size =last item index

	DataType temp = dataItems[0]; 
	dataItems[0] = dataItems[size]; // copying last index item to the deleting index item = size-1

	int i = 0;

	while (i < size)
	{
		Comparator com;
		if ((2 * i + 2) <= size)  //formula , (2i+2) & (2i+1)  // i=index

		{
			//No swap needed if the high priority

			// for max heap if i>a && i> b return temp
			if (com(dataItems[i].getPriority(), dataItems[(i * 2) + 1].getPriority()) &&
				com(dataItems[i].getPriority(), dataItems[(i * 2) + 2].getPriority()))
	
			{
				return temp;
			}

			//----------------------
			/*    
					  i
					/   \
				   a	  b       
			*/

			//---------------------------------------------------

			//Swap items if greater than  
			//if i <a && i< b  and ...else if ...(com(dataItems[(i * 2) + 2].getPriority(), dataItems[(i * 2) + 1].getPriority())))

			else if (com(dataItems[(i * 2) + 2].getPriority(), dataItems[(i * 2) + 1].getPriority()))
			{
				DataType temp = dataItems[i];
				dataItems[i] = dataItems[(i * 2) + 2];
				dataItems[(i * 2) + 2] = temp;
				i = (i* 2) + 2;
			}

			//Swap items if less than 
			//logic is when (com(dataItems[(i * 2) + 1].getPriority() > dataItems[(i * 2) + 2].getPriority())))

			else
			{
				DataType temp = dataItems[i];
				dataItems[i] = dataItems[i + 1];
				dataItems[(i * 2) + 1] = temp;
				i = (i * 2) + 1;
			}
		}

		//----------------

		else if ((i * 2) + 1 <= size)
		{
			
			 if (com(dataItems[(i * 2) + 1].getPriority(), dataItems[i].getPriority()))
			{
				DataType temp = dataItems[i];
				dataItems[i] = dataItems[(i * 2) + 1];
				dataItems[(i * 2) + 1] = temp;
				i = (i * 2) + 1;
			}
			else
			{
				return temp;
			}
		}
		else
		{
			return temp;
		}
	}

	return temp;
} 


template < typename DataType, typename KeyType, typename Comparator >
void Heap<DataType,KeyType,Comparator>::clear ()
{
	size = 0;
}



template < typename DataType, typename KeyType, typename Comparator >
bool Heap<DataType,KeyType,Comparator>::isEmpty () const
{
	return size==0;
}



template < typename DataType, typename KeyType, typename Comparator >
bool Heap<DataType,KeyType,Comparator>::isFull () const
{
	return size==maxSize;
}


template<typename DataType, typename KeyType, typename Comparator>
void Heap<DataType, KeyType, Comparator>::writeLevels() const 
{
	// next week 

	int lCount = 1;
	int pCount = 0;
	for (int i = 0; i < size; i++, pCount++)
	{
		if (pCount == lCount)
		{
			cout << endl;
			pCount = 0;
			lCount = 2*lCount;
		}
		cout << dataItems[i].getPriority() << " ";
	}
	cout << endl;

}

#include "show11.cpp"