//[ Sayem Chowdhury
//Lab:(05) ]
//---------------------------------------------

#include "ListLinked.h"

// ListNode member functions

template <typename DataType>
List<DataType>::ListNode::ListNode(const DataType& nodeData, ListNode* nextPtr) // constructor of ListNode
{
	this->dataItem = nodeData;
	this->next = nextPtr;
}

// List member functions

template <typename DataType>
List<DataType>::List(int ignored = 0) // constructor of List
{
	head = NULL;
	cursor = NULL;
}

template <typename DataType>
List<DataType>::List(const List& other) //copy constructor 
{
	if (other.head == NULL)
	{
		this->head == NULL;
	}
	else
	{
		ListNode *O_h = other.head;   // O_h: pointing other head
		ListNode *O_c = other.head;   // O_c: pointing other head

		this->head = this->cursor = new ListNode(O_c->dataItem, NULL); //creating a new node

		while (O_c->next != = NULL)
		{
			this->cursor->next = new ListNode(O_c->next->dataItem, NULL);
			this->cursor = this->cursor->next;
			O_c = O_c->next;
		}
	}
} 

template <typename DataType>
List<DataType>& List<DataType>::operator=(const List& other) //overloading assignment operator
{
	if (other.head == NULL)
	{
		this->head == NULL;
	}
	else
	{
		ListNode *O_h = other.head; // O_h: pointing other head
		ListNode *O_c = other.head; //O_c: pointing other cursor

		if (this != &other)
		{
			clear();
			this->head = this->cursor = new ListNode(O_c->dataItem, NULL); //creating a new node 

			while (O_c->next != NULL)
			{
				this->cursor->next = new ListNode(O_c->dataItem, NULL);
				this->cursor = this->cursor->next;
				O_c = O_c->next;
			}
			return *this;
		}
	}
}


template <typename DataType> // destructor 
List<DataType>::~List()
{
	clear();
}


//Insert Method
template <typename DataType>
void List<DataType>::insert(const DataType& newDataItem) throw (logic_error) // Insearting at the end of the node 
{
	
	if (head == NULL)
	{
		head = cursor = new ListNode(newDataItem, NULL);
	}

	else
	{
		while (cursor->next != NULL)
		{
			cursor = cursor->next;
		}
		cursor = cursor->next = new ListNode(newDataItem, cursor->next);
	}
	
}


template <typename DataType>
void List<DataType>::remove() throw (logic_error) // delete data Item mark by the cursor
{
	ListNode *p, *q;
	if (isEmpty())
	{
		throw("The list is empty ");
	}
	else if (cursor == head )
	{
		head = head->next;
		delete cursor;
		cursor = head;
	}

	else if (cursor!=NULL && cursor!=head)
	{
		p = head;
		while (p->next != cursor)
		{
			p = p->next;
		}

		if (p->next == cursor)
		{
			q = cursor;
			p->next = cursor->next;
			delete q;
			cursor = p;
		}
	}
	
}

template <typename DataType>
void List<DataType>::replace(const DataType& newDataItem) throw (logic_error)

{ 
	if (isEmpty())
	{
		throw ("The list is Empty");
	}
	else
	{
		cursor->dataItem = newDataItem;
	}

}

template <typename DataType>
void List<DataType>::clear()
{
	while (head != 0)
	{
		cursor = head;
		head = head->next;
		delete cursor;
	}

}

template <typename DataType>
bool List<DataType>::isEmpty() const
{
	if (head == NULL)
		return true;
	else
		return false;
}

template <typename DataType>
bool List<DataType>::isFull() const
{
	return false;
}

template <typename DataType>
void List<DataType>::gotoBeginning() throw (logic_error)
{
	if (isEmpty())
	{
		throw ("The list is Empty");
	}
	else if (cursor != head)
	{
		cursor = head;
	}

	else
	{ 
		cout << "cursor is at the beginning" << endl; 
	}
}

template <typename DataType>
void List<DataType>::gotoEnd() throw (logic_error)
{
	if (isEmpty())
	{
		throw ("The list is Empty");
	}
	else if (cursor == head && cursor->next==NULL)
	{
		cout << " The List have only single Node and cursor pointing That Node" << endl;

	} 
	else if (cursor->next == NULL)
	{
		cout << "cursor is at the end" << endl;
	}
	else 
	{
		while (cursor->next != NULL)
		{
			cursor = cursor->next;
		}
	}
}

template <typename DataType>
bool List<DataType>::gotoNext() throw (logic_error)
{
	
	if (isEmpty())
	{
		throw ("The list is Empty");
	}
	else if (cursor->next ==NULL)
	{
		cout << "There is no next NODE to go" << endl;
	}
	else
	{
		cursor = cursor->next;
	}
	//return false;
}

template <typename DataType>
bool List<DataType>::gotoPrior() throw (logic_error)
{
	ListNode *p;
	if (isEmpty())
	{
		throw ("The list is Empty");
	}
	else if (cursor==head)
	{
		cout << "There is no prior node in the list to go" << endl;
	}
	else
	{
		p = head;
		while (p->next != cursor)
		{
			p = p->next;
		}

		if (p->next == cursor)
		{
			cursor = p;
		}

	}
	//return false;
}

template <typename DataType>
DataType List<DataType>::getCursor() const throw (logic_error)
{
	if (isEmpty())
	{
		throw ("The list is Empty");
	}
	else
	{
		DataType t;
		t = cursor->dataItem;
		return t;
	}
}

template <typename DataType>
void List<DataType>::moveToBeginning () throw (logic_error)
{
	if (isEmpty())
	{
		throw ("The list is Empty");
	} 

	ListNode *q = new ListNode(cursor->dataItem, 0); //copied the the moving Item
	List<DataType>::remove();
	q->next = head;
	head = q;
	List<DataType>::gotoBeginning(); // moving cursor at the beginning 
}

template <typename DataType>
void List<DataType>::insertBefore(const DataType& newDataItem) throw (logic_error)
{
	if (isEmpty()) // while list is empty
	{
		head = cursor = new ListNode(newDataItem, NULL);
	}

	else if(!isEmpty() && cursor!=head) //while  cursor not at the head position 
	{
		ListNode *p= new ListNode(newDataItem, NULL);
		p->next = cursor;
		List<DataType>::gotoPrior();
		cursor->next = p;
		
	} 
	else if (!isEmpty() && cursor == head) // while cursor at the head 
	{
		ListNode *p = new ListNode(newDataItem, NULL);
		p->next = head;
		head = p;
		cursor = head; // cursor pointing at the newitem
	}
	
} 


#include "show5.cpp"

