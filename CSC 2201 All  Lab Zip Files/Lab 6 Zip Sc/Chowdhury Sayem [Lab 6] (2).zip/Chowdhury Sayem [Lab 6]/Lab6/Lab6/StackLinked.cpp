
#include "StackLinked.h"

template <typename DataType>
StackLinked<DataType>::StackLinked (int maxNumber)
{ 
	top = NULL;
}

template <typename DataType>
StackLinked<DataType>::StackLinked(const StackLinked& other)
{ 
	if (!isEmpty())
	{
		clear();
	} 
	if (other.top == NULL)
	{
		top = NULL;
	} 
	else
	{
		StackNode *other_cur=other.top; 
		top = new StackNode(other_cur->dataItem, NULL);

		StackNode *last = top;
		other_cur = other_cur->next;

		while (other_cur != NULL)
		{
			StackNode *newNode = new StackNode(other_cur->dataItem, NULL);
			last->next = newNode;
			last= newNode;
			other_cur = other_cur->next;
		}
	}
}

template <typename DataType>
StackLinked<DataType>& StackLinked<DataType>::operator=(const StackLinked& other)
{ 
	if (this != &other)
	{
		if (!isEmpty())
		{
			clear();
		}
		if (other.top == NULL)
		{
			top = NULL;
		}
		else
		{
			StackNode *other_cur = other.top;
			top = new StackNode(other_cur->dataItem, NULL);

			StackNode *last = top;
			other_cur = other_cur->next;

			while (other_cur != NULL)
			{
				StackNode *newNode = new StackNode(other_cur->dataItem, NULL);
				last->next = newNode;
				last = newNode;
				other_cur = other_cur->next;
			}
		}
	}
	teturn *this;
}

template <typename DataType>
StackLinked<DataType>::~StackLinked()
{
	clear();
}

template <typename DataType>
void StackLinked<DataType>::push(const DataType& newDataItem) throw (logic_error)
{ 
	if(isFull())
	{
		throw ("The List is Full");
	}
	StackNode *newNode = new StackNode(newDataItem, top);  
	top = newNode; 
}

template <typename DataType>
DataType StackLinked<DataType>::pop() throw (logic_error)
{
	if (top == NULL)
	{
		throw("The List is Empty");
	}
	else
	{ 
		StackNode *temp=top;
		DataType t = top->dataItem; 
		top = top->next;
		delete temp;
		return t;
	}
}

template <typename DataType>
void StackLinked<DataType>::clear()
{
	if (!isEmpty())
	{
		StackNode *temp=top;
		while (temp != NULL)
		{
			top = top->next;
			delete temp; 
			temp = top;
		}
	}

}
template <typename DataType>
bool StackLinked<DataType>::isEmpty() const
{
	return top == NULL;
}

template <typename DataType>
bool StackLinked<DataType>::isFull() const
{
	return false;
}

template <typename DataType>
void StackLinked<DataType>::showStructure() const
{
    if( isEmpty() )
    {
	cout << "Empty stack" << endl;
    }
    else
    {
        cout << "Top\t";
	for (StackNode* temp = top; temp != 0; temp = temp->next) {
	    if( temp == top ) {
		cout << "[" << temp->dataItem << "]\t";
	    }
	    else {
		cout << temp->dataItem << "\t";
	    }
	}
        cout << "Bottom" << endl;
    }

} 

