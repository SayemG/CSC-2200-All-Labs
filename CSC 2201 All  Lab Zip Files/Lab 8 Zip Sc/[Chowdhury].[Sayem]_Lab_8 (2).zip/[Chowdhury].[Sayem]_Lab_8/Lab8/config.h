/**
 * Expression Tree class (Lab 8) configuration file.
 * Activate test #N by defining the corresponding LAB8_TESTN to have the value 1.
 */

#define LAB8_TEST1	0	// Programming Exercise 1: Logic tree activator
#define LAB8_TEST2	1	// Programming Exercise 2: Commute operation
#define LAB8_TEST3	1	// Programming Exercise 3: isEquivalent operation

